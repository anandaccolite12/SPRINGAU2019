export class Book {
    id: string;
    bookName: string;
    authorName: string;
    description: string;
    price: number;

    constructor(id, name, desc, author, price){
        this.id = id;
        this.bookName = name;
        this.description = desc;
        this.authorName = author;
        this.price = price;
    }
}
