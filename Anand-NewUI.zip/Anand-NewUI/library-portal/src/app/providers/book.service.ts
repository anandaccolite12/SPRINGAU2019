import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class BookService {

  constructor(private http: HttpClient) { }

  getAllBooks(): Observable<any>{
    return this.http.get('/library/getbooks');
  }

  getBook(): Observable<any>{
    return this.http.get('/library/getbook');
  }

  addBook(book: any): Observable<any> {
    return this.http.post('/library/addbook', book);
  }

  addBookCart(book: any): Observable<any> {
    return this.http.post('/library/addcart', book);
  }

  getCartBooks(): Observable<any>{
    return this.http.get('/library/getcart');
  }

  removeBookCart(book: any): Observable<any> {
    return this.http.post('/library/deletecart', book);
  }
  
}
