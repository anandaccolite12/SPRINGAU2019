import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/providers/book.service';
import { Book } from 'src/app/model/book';


@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.scss']
})
export class AddComponent implements OnInit {

  book: any;

  id: string;
  title: string;
  desc: string;
  author: string;
  price: number;

  constructor(private bookService : BookService) { }

  ngOnInit() {
  }

  postData(){
    const book = new Book(this.id, this.title, this.desc, this.author, this.price);
     this.bookService.addBook(book).subscribe((response) => {
       console.log(this.id);
     });
  }

}
