import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/providers/book.service';

@Component({
  selector: 'app-viewcart',
  templateUrl: './viewcart.component.html',
  styleUrls: ['./viewcart.component.scss']
})
export class ViewcartComponent implements OnInit {
  books: any = [];
  index: number ;
  constructor(private bookService : BookService) { }

  ngOnInit() {
    this.bookService.getCartBooks().subscribe((response) => {
      console.log(response);
      if(response && response.length > 0){
        this.books = response;
      }
  });
  }


  postData(book){
    this.bookService.removeBookCart(book).subscribe((response) => {
       console.log(book);
     });

     this.index = this.books.indexOf(book);
      this.books.splice(this.index, 1);    
  }

}
