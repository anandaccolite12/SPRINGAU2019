import { Component, OnInit } from '@angular/core';
import { BookService } from 'src/app/providers/book.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

  books: any = [];
  index: number;

  constructor(private bookService : BookService) { }

  ngOnInit() {
    this.bookService.getAllBooks().subscribe((response) => {
        console.log(response);
        if(response && response.length > 0){
          this.books = response;
        }
    });
  }

  postData(book){
    this.bookService.addBookCart(book).subscribe((response) => {
       console.log(book);
     });
     console.log(this.books);
     this.index = this.books.indexOf(book);
      this.books.splice(this.index, 1);    
  }

}
